'VERSION 1.6.0.0
'http://comparenetobjects.codeplex.com/

'Uncomment to see breadcrumb messages in the debug window
'#define BREADCRUMB

'Uncomment to use settings from the app.config
'#define USE_SETTINGS

Option Infer On

#Region "Includes"
Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.Globalization
Imports System.Linq
Imports System.Net
Imports System.Text
Imports System.Reflection
Imports System.Collections
#If Not SILVERLIGHT Then
Imports System.Data
#End If

#If USE_SETTINGS Then
Imports KellermanSoftware.CompareNETObjects.Properties
#End If

#End Region

'This software is provided free of charge from Kellerman Software.
'It may be used in any project, including commercial for sale projects.
'
'Check out our other great software at www.kellermansoftware.com:
' *  Free Quick Reference Pack for Developers
' *  Free Sharp Zip Wrapper
' *  NUnit Test Generator
' * .NET Caching Library
' * .NET Email Validation Library
' * .NET FTP Library
' * .NET Encryption Library
' * .NET Logging Library
' * Themed Winform Wizard
' * Unused Stored Procedures
' * AccessDiff
' * .NET SFTP Library
' * Ninja Database Pro (Object database for .NET, Silverlight, Windows Phone 7)
' * Knight Data Access Layer (ORM, LINQ Provider, Generator)
#Region "License"
'Microsoft Public License (Ms-PL)

'This license governs use of the accompanying software. If you use the software, you accept this license. If you do not accept the license, do not use the software.

'1. Definitions

'The terms "reproduce," "reproduction," "derivative works," and "distribution" have the same meaning here as under U.S. copyright law.

'A "contribution" is the original software, or any additions or changes to the software.

'A "contributor" is any person that distributes its contribution under this license.

'"Licensed patents" are a contributor's patent claims that read directly on its contribution.

'2. Grant of Rights

'(A) Copyright Grant- Subject to the terms of this license, including the license conditions and limitations in section 3, each contributor grants you a non-exclusive, worldwide, royalty-free copyright license to reproduce its contribution, prepare derivative works of its contribution, and distribute its contribution or any derivative works that you create.

'(B) Patent Grant- Subject to the terms of this license, including the license conditions and limitations in section 3, each contributor grants you a non-exclusive, worldwide, royalty-free license under its licensed patents to make, have made, use, sell, offer for sale, import, and/or otherwise dispose of its contribution in the software or derivative works of the contribution in the software.

'3. Conditions and Limitations

'(A) No Trademark License- This license does not grant you rights to use any contributors' name, logo, or trademarks.

'(B) If you bring a patent claim against any contributor over patents that you claim are infringed by the software, your patent license from such contributor to the software ends automatically.

'(C) If you distribute any portion of the software, you must retain all copyright, patent, trademark, and attribution notices that are present in the software.

'(D) If you distribute any portion of the software in source code form, you may do so only under this license by including a complete copy of this license with your distribution. If you distribute any portion of the software in compiled or object code form, you may only do so under a license that complies with this license.

'(E) The software is licensed "as-is." You bear the risk of using it. The contributors give no express warranties, guarantees or conditions. You may have additional consumer rights under your local laws which this license cannot change. To the extent permitted under your local laws, the contributors exclude the implied warranties of merchantability, fitness for a particular purpose and non-infringement.
#End Region

Namespace KellermanSoftware.CompareNetObjects
	''' <summary>
	''' Class that allows comparison of two objects of the same type to each other.  Supports classes, lists, arrays, dictionaries, child comparison and more.
	''' </summary>
	''' <example>
	''' 
	''' CompareObjects compareObjects = new CompareObjects();
	''' 
	''' Person person1 = new Person();
	''' person1.DateCreated = DateTime.Now;
	''' person1.Name = "Greg";
	'''
	''' Person person2 = new Person();
	''' person2.Name = "John";
	''' person2.DateCreated = person1.DateCreated;
	'''
	''' if (!compareObjects.Compare(person1, person2))
	'''    Console.WriteLine(compareObjects.DifferencesString);
	''' 
	''' </example>
	Public Class CompareObjects
		#Region "Class Variables"

		''' <summary>
		''' Keep track of parent objects in the object hiearchy
		''' </summary>
		Private ReadOnly _parents As New List(Of Object)()

		''' <summary>
		''' Reflection Cache for property info
		''' </summary>
		Private ReadOnly _propertyCache As New Dictionary(Of Type, PropertyInfo())()

		''' <summary>
		''' Reflection Cache for field info
		''' </summary>
		Private ReadOnly _fieldCache As New Dictionary(Of Type, FieldInfo())()

		''' <summary>
		''' Reflection Cache for methods
		''' </summary>
		Private Shared ReadOnly _methodList As New Dictionary(Of Type, MethodInfo())()
		#End Region

		#Region "Properties"

		''' <summary>
		''' Ignore classes, properties, or fields by name during the comparison.
		''' Case sensitive.
		''' </summary>
		''' <example>ElementsToIgnore.Add("CreditCardNumber")</example>
		Public Property ElementsToIgnore() As List(Of String)

		''' <summary>
		''' Only compare elements by name for classes, properties, and fields
		''' Case sensitive.
		''' </summary>
		''' <example>ElementsToInclude.Add("FirstName")</example>
		Public Property ElementsToInclude() As List(Of String)

'Security restriction in Silverlight prevents getting private properties and fields
#If Not SILVERLIGHT Then
		''' <summary>
		''' If true, private properties and fields will be compared. The default is false.  Silverlight and WinRT restricts access to private variables.
		''' </summary>
		Public Property ComparePrivateProperties() As Boolean

		''' <summary>
		''' If true, private fields will be compared. The default is false.  Silverlight and WinRT restricts access to private variables.
		''' </summary>
		Public Property ComparePrivateFields() As Boolean
#End If

		''' <summary>
		''' If true, static properties will be compared.  The default is true.
		''' </summary>
		Public Property CompareStaticProperties() As Boolean

		''' <summary>
		''' If true, static fields will be compared.  The default is true.
		''' </summary>
		Public Property CompareStaticFields() As Boolean

		''' <summary>
		''' If true, child objects will be compared. The default is true. 
		''' If false, and a list or array is compared list items will be compared but not their children.
		''' </summary>
		Public Property CompareChildren() As Boolean

		''' <summary>
		''' If true, compare read only properties (only the getter is implemented).
		''' The default is true.
		''' </summary>
		Public Property CompareReadOnly() As Boolean

		''' <summary>
		''' If true, compare fields of a class (see also CompareProperties).
		''' The default is true.
		''' </summary>
		Public Property CompareFields() As Boolean

		''' <summary>
		''' If true, compare properties of a class (see also CompareFields).
		''' The default is true.
		''' </summary>
		Public Property CompareProperties() As Boolean

		''' <summary>
		''' The maximum number of differences to detect
		''' </summary>
		''' <remarks>
		''' Default is 1 for performance reasons.
		''' </remarks>
		Public Property MaxDifferences() As Integer

		''' <summary>
		''' The differences found during the compare
		''' </summary>
		Public Property Differences() As List(Of Difference)

		''' <summary>
		''' The differences found in a string suitable for a textbox
		''' </summary>
		Public ReadOnly Property DifferencesString() As String
			Get
				Dim sb As New StringBuilder(4096)

				sb.AppendLine()
				sb.AppendLine("Begin Differences:")

				For Each item As Difference In Differences
					sb.AppendLine(item.ToString())
				Next item

				sb.AppendFormat("End Differences (Maximum of {0} differences shown).", MaxDifferences)

				Return sb.ToString()
			End Get
		End Property

		''' <summary>
		''' Reflection properties and fields are cached. By default this cache is cleared after each compare.  Set to false to keep the cache for multiple compares.
		''' </summary>
		''' <seealso cref="Caching"/>
		''' <seealso cref="ClearCache"/>
		Public Property AutoClearCache() As Boolean

		''' <summary>
		''' By default properties and fields for types are cached for each compare.  By default this cache is cleared after each compare.
		''' </summary>
		''' <seealso cref="AutoClearCache"/>
		''' <seealso cref="ClearCache"/>
		Public Property Caching() As Boolean

		''' <summary>
		''' A list of attributes to ignore a class, property or field
		''' </summary>
		''' <example>AttributesToIgnore.Add(typeof(XmlIgnoreAttribute));</example>
		Public Property AttributesToIgnore() As List(Of Type)

		''' <summary>
		''' If true, objects will be compared ignore their type diferences
		''' </summary>
		Public Property IgnoreObjectTypes() As Boolean

		''' <summary>
		''' Func that determine when use CustomComparer for comparing specific type.
		''' Default value return permanent false value.
		''' </summary>
		Public Property IsUseCustomTypeComparer() As Func(Of Type, Boolean)

		''' <summary>
		''' Action that performed for comparing objects.
		''' T1: contain current CompareObjects
		''' T2: object1 for comparing
		''' T3: object1 for comparing
		''' T4: current CompareObjects breadcrumb
		''' </summary>
		Public Property CustomComparer() As Action(Of CompareObjects, Object, Object, String)

		''' <summary>
		''' In the differences string, this is the name for expected name, default is Expected 
		''' </summary>
		Public Property ExpectedName() As String

		''' <summary>
		''' In the differences string, this is the name for the actual name, default is Actual
		''' </summary>
		Public Property ActualName() As String
		#End Region

		#Region "Constructor"

		''' <summary>
		''' Set up defaults for the comparison
		''' </summary>
		Public Sub New()
			Differences = New List(Of Difference)()
			AttributesToIgnore = New List(Of Type)()
			CustomComparer = Nothing

#If Not USE_SETTINGS Then
			SetupWithoutReadingSettings()
#Else
			SetupWithSettings()
#End If
		End Sub

		Private Sub SetupWithoutReadingSettings()
			ElementsToIgnore = New List(Of String)()
			ElementsToInclude = New List(Of String)()
			CompareStaticFields = True
			CompareStaticProperties = True
#If Not SILVERLIGHT Then
			ComparePrivateProperties = False
			ComparePrivateFields = False
#End If
			CompareChildren = True
			CompareReadOnly = True
			CompareFields = True
			CompareProperties = True
			Caching = True
			AutoClearCache = True
			IgnoreObjectTypes = False
			MaxDifferences = 1
			IsUseCustomTypeComparer = Function(t) False
			ExpectedName = "Expected"
			ActualName = "Actual"
		End Sub

		#If USE_SETTINGS Then
		Private Sub SetupWithSettings()
			ElementsToIgnore = If(Settings.Default.ElementsToIgnore Is Nothing, New List(Of String)(), New List(Of String)(CType(Settings.Default.ElementsToIgnore, IEnumerable(Of String))))

			If Settings.Default.ElementsToIgnore IsNot Nothing Then
				For Each attribute In Settings.Default.ElementsToIgnore
					AttributesToIgnore.Add(Type.GetType(attribute))
				Next attribute
			End If

			CompareStaticFields = Settings.Default.CompareStaticFields
			CompareStaticProperties = Settings.Default.CompareStaticProperties

			#If Not SILVERLIGHT Then
			ComparePrivateProperties = Settings.Default.ComparePrivateProperties
			ComparePrivateFields = Settings.Default.ComparePrivateFields
			#End If

			CompareChildren = Settings.Default.CompareChildren
			CompareReadOnly = Settings.Default.CompareReadOnly
			CompareFields = Settings.Default.CompareFields
			CompareProperties = Settings.Default.CompareProperties
			Caching = Settings.Default.Caching
			AutoClearCache = Settings.Default.AutoClearCache
			MaxDifferences = 1
'INSTANT VB NOTE: The variable maxDifferences was renamed since Visual Basic does not handle local variables named the same as class members well:
			Dim maxDifferences_Renamed As Integer
			If Int32.TryParse(Settings.Default.MaxDifferences, maxDifferences_Renamed) Then
				MaxDifferences = maxDifferences_Renamed
			End If

		End Sub
		#End If

		#End Region

		#Region "Public Methods"
		''' <summary>
		''' Compare two objects of the same type to each other.
		''' </summary>
		''' <remarks>
		''' Check the Differences or DifferencesString Properties for the differences.
		''' Default MaxDifferences is 1 for performance
		''' </remarks>
		''' <param name="object1"></param>
		''' <param name="object2"></param>
		''' <returns>True if they are equal</returns>
		Public Function Compare(ByVal object1 As Object, ByVal object2 As Object) As Boolean
			Dim defaultBreadCrumb As String = String.Empty

			Differences.Clear()
			Compare(object1, object2, defaultBreadCrumb)

			If AutoClearCache Then
				ClearCache()
			End If

			Return Differences.Count = 0
		End Function

		''' <summary>
		''' Reflection properties and fields are cached. By default this cache is cleared automatically after each compare.
		''' </summary>
		''' <seealso cref="AutoClearCache"/>
		''' <seealso cref="Caching"/>
		Public Sub ClearCache()
			_propertyCache.Clear()
			_fieldCache.Clear()
			_methodList.Clear()
		End Sub

		#End Region

		#Region "Comparison Methods"

		''' <summary>
		''' Compare two objects
		''' </summary>
		''' <param name="object1">The first object to compare</param>
		''' <param name="object2">The second object to compare</param>
		''' <param name="breadCrumb">Where we are in the object hiearchy</param>
		Private Sub Compare(ByVal object1 As Object, ByVal object2 As Object, ByVal breadCrumb As String)
			'If both null return true
			If object1 Is Nothing AndAlso object2 Is Nothing Then
				Return
			End If

			'Check if one of them is null
			If object1 Is Nothing Then
				Dim difference As Difference = New Difference With {.ExpectedName = ExpectedName, .ActualName = ActualName, .PropertyName = breadCrumb, .Object1Value = "(null)", .Object2Value = NiceString(object2)}
				Differences.Add(difference)
				Return
			End If

			If object2 Is Nothing Then
				Dim difference As Difference = New Difference With {.ExpectedName = ExpectedName, .ActualName = ActualName, .PropertyName = breadCrumb, .Object1Value = NiceString(object1), .Object2Value = "(null)"}
				Differences.Add(difference)
				Return
			End If

			Dim t1 As Type = object1.GetType()
			Dim t2 As Type = object2.GetType()

			'Objects must be the same type
			If t1 <> t2 AndAlso (Not IgnoreObjectTypes) Then
				Dim difference As Difference = New Difference With {.ExpectedName = ExpectedName, .ActualName = ActualName, .PropertyName = breadCrumb, .Object1Value = t1.FullName, .Object2Value = t2.FullName, .ChildPropertyName = "GetType()", .MessagePrefix = "Different Types"}
				Differences.Add(difference)

				Return
			End If

			If IsUseCustomTypeComparer(t1) Then
				CompareWithCustomComparer(object1, object2, breadCrumb)
			ElseIf IsTypeOfType(t1) Then
				CompareType(object1, object2, breadCrumb)
			ElseIf IsIPEndPoint(t1) Then
				CompareIpEndPoint(object1, object2, breadCrumb)
#If Not SILVERLIGHT Then
			ElseIf IsDataset(t1) Then
				CompareDataset(object1, object2, breadCrumb)
			ElseIf IsDataTable(t1) Then
				CompareDataTable(object1, object2, breadCrumb)
			ElseIf IsDataRow(t1) Then
				CompareDataRow(object1, object2, breadCrumb)
#End If
			ElseIf IsIList(t1) Then 'This will do arrays, multi-dimensional arrays and generic lists
				CompareIList(object1, object2, breadCrumb)
			ElseIf IsHashSet(t1) Then
				CompareHashSet(object1,object2,breadCrumb)
			ElseIf IsIDictionary(t1) Then
				CompareIDictionary(object1, object2, breadCrumb)
			ElseIf IsEnum(t1) Then
				CompareEnum(object1, object2, breadCrumb)
			ElseIf IsPointer(t1) Then
				ComparePointer(object1, object2, breadCrumb)
			ElseIf IsUri(t1) Then
				CompareUri(object1, object2, breadCrumb)
			ElseIf IsSimpleType(t1) Then
				CompareSimpleType(object1, object2, breadCrumb)
			ElseIf IsClass(t1) Then
				CompareClass(object1, object2, breadCrumb)
			ElseIf IsTimespan(t1) Then
				CompareTimespan(object1, object2, breadCrumb)
			ElseIf IsStruct(t1) Then
				CompareStruct(object1, object2, breadCrumb)
			Else
				Throw New NotSupportedException("Cannot compare object of type " & t1.Name)
			End If

		End Sub

		Private Sub CompareIpEndPoint(ByVal object1 As Object, ByVal object2 As Object, ByVal breadCrumb As String)
			Dim ipEndPoint1 As IPEndPoint = TryCast(object1, IPEndPoint)
			Dim ipEndPoint2 As IPEndPoint = TryCast(object2, IPEndPoint)

			'Null check happens above
			If ipEndPoint1 Is Nothing OrElse ipEndPoint2 Is Nothing Then
				Return
			End If

			If ipEndPoint1.Port <> ipEndPoint2.Port Then
				Dim difference As Difference = New Difference With {.ExpectedName = ExpectedName, .ActualName = ActualName, .PropertyName = breadCrumb, .Object1Value = ipEndPoint1.Port.ToString(CultureInfo.InvariantCulture), .Object2Value = ipEndPoint2.Port.ToString(CultureInfo.InvariantCulture), .ChildPropertyName = "Port"}
				Differences.Add(difference)
			End If

			If Differences.Count >= MaxDifferences Then
				Return
			End If

			If ipEndPoint1.Address.ToString() <> ipEndPoint2.Address.ToString() Then
				Dim difference As Difference = New Difference With {.ExpectedName = ExpectedName, .ActualName = ActualName, .PropertyName = breadCrumb, .Object1Value = ipEndPoint1.Address.ToString(), .Object2Value = ipEndPoint2.Address.ToString(), .ChildPropertyName = "Address"}
				Differences.Add(difference)
			End If
		End Sub

		''' <summary>
		''' Compare an object of type URI
		''' </summary>
		''' <param name="object1"></param>
		''' <param name="object2"></param>
		''' <param name="breadCrumb"></param>
		Private Sub CompareUri(ByVal object1 As Object, ByVal object2 As Object, ByVal breadCrumb As String)
			Dim uri1 As Uri = TryCast(object1, Uri)
			Dim uri2 As Uri = TryCast(object2, Uri)

			'This should never happen, null check happens one level up
			If uri1 Is Nothing OrElse uri2 Is Nothing Then
				Return
			End If

			If uri1.OriginalString <> uri2.OriginalString Then
				Dim difference As Difference = New Difference With {.ExpectedName = ExpectedName, .ActualName = ActualName, .PropertyName = breadCrumb, .Object1Value = NiceString(uri1.OriginalString), .Object2Value = NiceString(uri2.OriginalString), .ChildPropertyName = "OriginalString"}
				Differences.Add(difference)
			End If
		End Sub

		''' <summary>
		''' Compare an object of type Type (Runtime type)
		''' </summary>
		''' <param name="object1"></param>
		''' <param name="object2"></param>
		''' <param name="breadCrumb"></param>
		Private Sub CompareType(ByVal object1 As Object, ByVal object2 As Object, ByVal breadCrumb As String)
			Dim t1 As Type = CType(object1, Type)
			Dim t2 As Type = CType(object2, Type)

			If t1.FullName <> t2.FullName Then
				Dim difference As Difference = New Difference With {.ExpectedName = ExpectedName, .ActualName = ActualName, .PropertyName = breadCrumb, .Object1Value = t1.FullName, .Object2Value = t2.FullName, .ChildPropertyName = "FullName"}
				Differences.Add(difference)
			End If
		End Sub

#If Not SILVERLIGHT Then

		''' <summary>
		''' Compare all columns in a data row
		''' </summary>
		''' <param name="object1"></param>
		''' <param name="object2"></param>
		''' <param name="breadCrumb"></param>
		Private Sub CompareDataRow(ByVal object1 As Object, ByVal object2 As Object, ByVal breadCrumb As String)
			Dim dataRow1 As DataRow = TryCast(object1, DataRow)
			Dim dataRow2 As DataRow = TryCast(object2, DataRow)

			'This should never happen, null check happens one level up
			If dataRow1 Is Nothing OrElse dataRow2 Is Nothing Then
				Return
			End If

			For i As Integer = 0 To dataRow1.Table.Columns.Count - 1
				'Only compare specific column names
				If ElementsToInclude.Count > 0 AndAlso (Not ElementsToInclude.Contains(dataRow1.Table.Columns(i).ColumnName)) Then
					Continue For
				End If

				'If we should ignore it, skip it
				If ElementsToInclude.Count = 0 AndAlso ElementsToIgnore.Contains(dataRow1.Table.Columns(i).ColumnName) Then
					Continue For
				End If

				'If we should ignore read only, skip it
				If (Not CompareReadOnly) AndAlso dataRow1.Table.Columns(i).ReadOnly Then
					Continue For
				End If

				'Both are null
				If dataRow1.IsNull(i) AndAlso dataRow2.IsNull(i) Then
					Continue For
				End If

				Dim currentBreadCrumb As String = AddBreadCrumb(breadCrumb, String.Empty, String.Empty, dataRow1.Table.Columns(i).ColumnName)

				'Check if one of them is null
				If dataRow1.IsNull(i) Then
					Dim difference As Difference = New Difference With {.ExpectedName = ExpectedName, .ActualName = ActualName, .PropertyName = currentBreadCrumb, .Object1Value = "(null)", .Object2Value = NiceString(object2)}
					Differences.Add(difference)
					Return
				End If

				If dataRow2.IsNull(i) Then
					Dim difference As Difference = New Difference With {.ExpectedName = ExpectedName, .ActualName = ActualName, .PropertyName = currentBreadCrumb, .Object1Value = NiceString(object1), .Object2Value = "(null)"}
					Differences.Add(difference)
					Return
				End If

				Compare(dataRow1(i), dataRow2(i), currentBreadCrumb)

				If Differences.Count >= MaxDifferences Then
					Return
				End If
			Next i
		End Sub

		''' <summary>
		''' Compare all rows in a data table
		''' </summary>
		''' <param name="object1"></param>
		''' <param name="object2"></param>
		''' <param name="breadCrumb"></param>
		Private Sub CompareDataTable(ByVal object1 As Object, ByVal object2 As Object, ByVal breadCrumb As String)
			Dim dataTable1 As DataTable = TryCast(object1, DataTable)
			Dim dataTable2 As DataTable = TryCast(object2, DataTable)

			'This should never happen, null check happens one level up
			If dataTable1 Is Nothing OrElse dataTable2 Is Nothing Then
				Return
			End If

			'Only compare specific table names
			If ElementsToInclude.Count > 0 AndAlso (Not ElementsToInclude.Contains(dataTable1.TableName)) Then
				Return
			End If

			'If we should ignore it, skip it
			If ElementsToInclude.Count = 0 AndAlso ElementsToIgnore.Contains(dataTable1.TableName) Then
				Return
			End If

			'There must be the same amount of rows in the datatable
			If dataTable1.Rows.Count <> dataTable2.Rows.Count Then
				Dim difference As Difference = New Difference With {.ExpectedName = ExpectedName, .ActualName = ActualName, .PropertyName = breadCrumb, .Object1Value = dataTable1.Rows.Count.ToString(CultureInfo.InvariantCulture), .Object2Value = dataTable2.Rows.Count.ToString(CultureInfo.InvariantCulture), .ChildPropertyName = "Rows.Count"}
				Differences.Add(difference)

				If Differences.Count >= MaxDifferences Then
					Return
				End If
			End If

			'There must be the same amount of columns in the datatable
			If dataTable1.Columns.Count <> dataTable2.Columns.Count Then
				Dim difference As Difference = New Difference With {.ExpectedName = ExpectedName, .ActualName = ActualName, .PropertyName = breadCrumb, .Object1Value = dataTable1.Columns.Count.ToString(CultureInfo.InvariantCulture), .Object2Value = dataTable2.Columns.Count.ToString(CultureInfo.InvariantCulture), .ChildPropertyName = "Columns.Count"}
				Differences.Add(difference)

				If Differences.Count >= MaxDifferences Then
					Return
				End If
			End If

			For i As Integer = 0 To Math.Min(dataTable1.Rows.Count,dataTable2.Rows.Count) - 1
				Dim currentBreadCrumb As String = AddBreadCrumb(breadCrumb, "Rows", String.Empty, i)

				CompareDataRow(dataTable1.Rows(i), dataTable2.Rows(i), currentBreadCrumb)

				If Differences.Count >= MaxDifferences Then
					Return
				End If
			Next i
		End Sub

		''' <summary>
		''' Compare all tables and all rows in all tables
		''' </summary>
		''' <param name="object1"></param>
		''' <param name="object2"></param>
		''' <param name="breadCrumb"></param>
		Private Sub CompareDataset(ByVal object1 As Object, ByVal object2 As Object, ByVal breadCrumb As String)
			Dim dataSet1 As DataSet = TryCast(object1, DataSet)
			Dim dataSet2 As DataSet = TryCast(object2, DataSet)

			'This should never happen, null check happens one level up
			If dataSet1 Is Nothing OrElse dataSet2 Is Nothing Then
				Return
			End If

			'There must be the same amount of tables in the dataset
			If dataSet1.Tables.Count <> dataSet2.Tables.Count Then
				Dim difference As Difference = New Difference With {.ExpectedName = ExpectedName, .ActualName = ActualName, .PropertyName = breadCrumb, .Object1Value = dataSet1.Tables.Count.ToString(CultureInfo.InvariantCulture), .Object2Value = dataSet2.Tables.Count.ToString(CultureInfo.InvariantCulture), .ChildPropertyName = "Tables.Count"}
				Differences.Add(difference)

				If Differences.Count >= MaxDifferences Then
					Return
				End If
			End If

			For i As Integer = 0 To Math.Min(dataSet1.Tables.Count,dataSet2.Tables.Count) - 1
				Dim currentBreadCrumb As String = AddBreadCrumb(breadCrumb, "Tables", String.Empty, dataSet1.Tables(i).TableName)

				CompareDataTable(dataSet1.Tables(i), dataSet2.Tables(i), currentBreadCrumb)

				If Differences.Count >= MaxDifferences Then
					Return
				End If
			Next i
		End Sub
#End If

		''' <summary>
		''' Compare a timespan struct
		''' </summary>
		''' <param name="object1"></param>
		''' <param name="object2"></param>
		''' <param name="breadCrumb"></param>
		Private Sub CompareTimespan(ByVal object1 As Object, ByVal object2 As Object, ByVal breadCrumb As String)
			If CType(object1, TimeSpan).Ticks <> CType(object2, TimeSpan).Ticks Then
				Dim difference As Difference = New Difference With {.ExpectedName = ExpectedName, .ActualName = ActualName, .PropertyName = breadCrumb, .Object1Value = CType(object1, TimeSpan).Ticks.ToString(CultureInfo.InvariantCulture), .Object2Value = CType(object1, TimeSpan).Ticks.ToString(CultureInfo.InvariantCulture), .ChildPropertyName = "Ticks"}
				Differences.Add(difference)
			End If
		End Sub

		''' <summary>
		''' Compare a pointer struct
		''' </summary>
		''' <param name="object1"></param>
		''' <param name="object2"></param>
		''' <param name="breadCrumb"></param>
		Private Sub ComparePointer(ByVal object1 As Object, ByVal object2 As Object, ByVal breadCrumb As String)
			If (TypeOf object1 Is IntPtr AndAlso TypeOf object2 Is IntPtr AndAlso (CType(object1, IntPtr)) <> (CType(object2, IntPtr))) OrElse (TypeOf object1 Is UIntPtr AndAlso TypeOf object2 Is UIntPtr AndAlso (CType(object1, UIntPtr)) <> (CType(object2, UIntPtr))) Then
				Dim difference As Difference = New Difference With {.ExpectedName = ExpectedName, .ActualName = ActualName, .PropertyName = breadCrumb}
				Differences.Add(difference)
			End If
		End Sub

		''' <summary>
		''' Compare an enumeration
		''' </summary>
		''' <param name="object1"></param>
		''' <param name="object2"></param>
		''' <param name="breadCrumb"></param>
		Private Sub CompareEnum(ByVal object1 As Object, ByVal object2 As Object, ByVal breadCrumb As String)
			If object1.ToString() <> object2.ToString() Then
				Dim currentBreadCrumb As String = AddBreadCrumb(breadCrumb, object1.GetType().Name, String.Empty, -1)

				Dim difference As Difference = New Difference With {.ExpectedName = ExpectedName, .ActualName = ActualName, .PropertyName = currentBreadCrumb, .Object1Value = object1.ToString(), .Object2Value = object2.ToString()}
				Differences.Add(difference)
			End If
		End Sub

		''' <summary>
		''' Compare a simple type
		''' </summary>
		''' <param name="object1"></param>
		''' <param name="object2"></param>
		''' <param name="breadCrumb"></param>
		Private Sub CompareSimpleType(ByVal object1 As Object, ByVal object2 As Object, ByVal breadCrumb As String)
			'This should never happen, null check happens one level up
			If object2 Is Nothing OrElse object1 Is Nothing Then
				Return
			End If

			Dim valOne As IComparable = TryCast(object1, IComparable)

			If valOne Is Nothing Then
				Throw New Exception("Expected value does not implement IComparable")
			End If

			If valOne.CompareTo(object2) <> 0 Then
				Dim difference As Difference = New Difference With {.ExpectedName = ExpectedName, .ActualName = ActualName, .PropertyName = breadCrumb, .Object1Value = object1.ToString(), .Object2Value = object2.ToString()}
				Differences.Add(difference)
			End If
		End Sub

		''' <summary>
		''' Compare a struct
		''' </summary>
		''' <param name="object1"></param>
		''' <param name="object2"></param>
		''' <param name="breadCrumb"></param>
		Private Sub CompareStruct(ByVal object1 As Object, ByVal object2 As Object, ByVal breadCrumb As String)
			Try
				_parents.Add(object1)
				_parents.Add(object2)

				Dim t1 As Type = object1.GetType()

				PerformCompareFields(t1, object1, object2, True, breadCrumb)
				PerformCompareProperties(t1, object1, object2, True, breadCrumb)
			Finally
				_parents.Remove(object1)
				_parents.Remove(object2)
			End Try
		End Sub

		''' <summary>
		''' Compare the properties, fields of a class
		''' </summary>
		''' <param name="object1"></param>
		''' <param name="object2"></param>
		''' <param name="breadCrumb"></param>
		Private Sub CompareClass(ByVal object1 As Object, ByVal object2 As Object, ByVal breadCrumb As String)
			Try
				_parents.Add(object1)
				_parents.Add(object2)

				Dim t1 As Type = object1.GetType()

				'Only compare specific class names
				If ElementsToInclude.Count > 0 AndAlso (Not ElementsToInclude.Contains(t1.Name)) Then
					Return
				End If

				'We ignore the class name
				If (ElementsToInclude.Count = 0 AndAlso ElementsToIgnore.Contains(t1.Name)) OrElse IgnoredByAttribute(t1) Then
					Return
				End If

				'Compare the properties
				If CompareProperties Then
					PerformCompareProperties(t1, object1, object2, False, breadCrumb)
				End If

				'Compare the fields
				If CompareFields Then
					PerformCompareFields(t1, object1, object2, False, breadCrumb)
				End If
			Finally
				_parents.Remove(object1)
				_parents.Remove(object2)
			End Try
		End Sub

		Private Sub CompareWithCustomComparer(ByVal object1 As Object, ByVal object2 As Object, ByVal breadCrumb As String)
			If CustomComparer IsNot Nothing Then
				CustomComparer()(Me, object1, object2, breadCrumb)
			End If
		End Sub

		''' <summary>
		''' Compare the fields of a class
		''' </summary>
		''' <param name="t1"></param>
		''' <param name="object1"></param>
		''' <param name="object2"></param>
		''' <param name="structCompare"></param>
		''' <param name="breadCrumb"></param>
		Private Sub PerformCompareFields(ByVal t1 As Type, ByVal object1 As Object, ByVal object2 As Object, ByVal structCompare As Boolean, ByVal breadCrumb As String)
			Dim currentFields As IEnumerable(Of FieldInfo) = GetFieldInfo(t1)

			For Each item As FieldInfo In currentFields
				'Ignore invalid struct fields
				If structCompare AndAlso (Not ValidStructSubType(item.FieldType)) Then
					Continue For
				End If

				'Skip if this is a shallow compare
				If (Not CompareChildren) AndAlso IsChildType(item.FieldType) Then
					Continue For
				End If

				'Only compare specific field names
				If ElementsToInclude.Count > 0 AndAlso (Not ElementsToInclude.Contains(item.Name)) Then
					Continue For
				End If

				'If we should ignore it, skip it
				If (ElementsToInclude.Count = 0 AndAlso ElementsToIgnore.Contains(item.Name)) OrElse IgnoredByAttribute(item.FieldType) Then
					Continue For
				End If

				Dim objectValue1 As Object = item.GetValue(object1)
				Dim objectValue2 As Object = item.GetValue(object2)

				Dim object1IsParent As Boolean = objectValue1 IsNot Nothing AndAlso (objectValue1 Is object1 OrElse _parents.Contains(objectValue1))
				Dim object2IsParent As Boolean = objectValue2 IsNot Nothing AndAlso (objectValue2 Is object2 OrElse _parents.Contains(objectValue2))

				'Skip fields that point to the parent
				If IsClass(item.FieldType) AndAlso (object1IsParent OrElse object2IsParent) Then
					Continue For
				End If

				Dim currentCrumb As String = AddBreadCrumb(breadCrumb, item.Name, String.Empty, -1)

				Compare(objectValue1, objectValue2, currentCrumb)

				If Differences.Count >= MaxDifferences Then
					Return
				End If
			Next item
		End Sub

		''' <summary>
		''' Get a list of the fields within a type
		''' </summary>
		''' <param name="type"></param>
		''' <returns></returns>
		Private Function GetFieldInfo(ByVal type As Type) As IEnumerable(Of FieldInfo)
			If Caching AndAlso _fieldCache.ContainsKey(type) Then
				Return _fieldCache(type)
			End If

			Dim currentFields() As FieldInfo

#If Not SILVERLIGHT Then
			If ComparePrivateFields AndAlso (Not CompareStaticFields) Then
				Dim list As New List(Of FieldInfo)()
				Dim t As Type = type
				Do
					list.AddRange(t.GetFields(BindingFlags.Public Or BindingFlags.NonPublic Or BindingFlags.Instance))
					t = t.BaseType
				Loop While t IsNot Nothing
				currentFields = list.ToArray()
			ElseIf ComparePrivateFields AndAlso CompareStaticFields Then
				Dim list As New List(Of FieldInfo)()
				Dim t As Type = type
				Do
					list.AddRange(t.GetFields(BindingFlags.Public Or BindingFlags.Instance Or BindingFlags.NonPublic Or BindingFlags.Static))
					t = t.BaseType
				Loop While t IsNot Nothing
				currentFields = list.ToArray()
			Else
#End If
				currentFields = type.GetFields() 'Default is public instance and static
			End If

			If Caching Then
				_fieldCache.Add(type, currentFields)
			End If

			Return currentFields
		End Function


		''' <summary>
		''' Compare the properties of a class
		''' </summary>
		''' <param name="t1"></param>
		''' <param name="object1"></param>
		''' <param name="object2"></param>
		''' <param name="structCompare"></param>
		''' <param name="breadCrumb"></param>
		Private Sub PerformCompareProperties(ByVal t1 As Type, ByVal object1 As Object, ByVal object2 As Object, ByVal structCompare As Boolean, ByVal breadCrumb As String)
			Dim currentProperties As IEnumerable(Of PropertyInfo) = GetPropertyInfo(t1)

			For Each info As PropertyInfo In currentProperties
				'Ignore invalid struct fields
				If structCompare AndAlso (Not ValidStructSubType(info.PropertyType)) Then
					Continue For
				End If

				'If we can't read it, skip it
				If info.CanRead = False Then
					Continue For
				End If

				'Skip if this is a shallow compare
				If (Not CompareChildren) AndAlso IsChildType(info.PropertyType) Then
					Continue For
				End If

				'Only compare specific property names
				If ElementsToInclude.Count > 0 AndAlso (Not ElementsToInclude.Contains(info.Name)) Then
					Continue For
				End If

				'If we should ignore it, skip it
				If (ElementsToInclude.Count = 0 AndAlso ElementsToIgnore.Contains(info.Name)) OrElse IgnoredByAttribute(info.PropertyType) Then
					Continue For
				End If

				'If we should ignore read only, skip it
				If (Not CompareReadOnly) AndAlso info.CanWrite = False Then
					Continue For
				End If

				'If we ignore types then we must get correct PropertyInfo object
				Dim secondObjectInfo As PropertyInfo = Nothing
				If IgnoreObjectTypes Then
					Dim secondObjectPropertyInfos = GetPropertyInfo(object2.GetType())

					For Each propertyInfo In secondObjectPropertyInfos
						If propertyInfo.Name <> info.Name Then
							Continue For
						End If

						secondObjectInfo = propertyInfo
						Exit For
					Next propertyInfo
				Else
					secondObjectInfo = info
				End If

				Dim objectValue1 As Object
				Dim objectValue2 As Object
				If Not IsValidIndexer(info, breadCrumb) Then
					objectValue1 = info.GetValue(object1, Nothing)
					objectValue2 = If(secondObjectInfo IsNot Nothing, secondObjectInfo.GetValue(object2, Nothing), Nothing)
				Else
					CompareIndexer(info, object1, object2, breadCrumb)
					Continue For
				End If

				Dim object1IsParent As Boolean = objectValue1 IsNot Nothing AndAlso (objectValue1 Is object1 OrElse _parents.Contains(objectValue1))
				Dim object2IsParent As Boolean = objectValue2 IsNot Nothing AndAlso (objectValue2 Is object2 OrElse _parents.Contains(objectValue2))

				'Skip properties where both point to the corresponding parent
				If (IsClass(info.PropertyType) OrElse IsStruct(info.PropertyType)) AndAlso (object1IsParent AndAlso object2IsParent) Then
					Continue For
				End If

				Dim currentCrumb As String = AddBreadCrumb(breadCrumb, info.Name, String.Empty, -1)

				Compare(objectValue1, objectValue2, currentCrumb)

				If Differences.Count >= MaxDifferences Then
					Return
				End If
			Next info
		End Sub

		''' <summary>
		''' Get a list of the properties in a type
		''' </summary>
		''' <param name="type"></param>
		''' <returns></returns>
		Private Function GetPropertyInfo(ByVal type As Type) As IEnumerable(Of PropertyInfo)
			If Caching AndAlso _propertyCache.ContainsKey(type) Then
				Return _propertyCache(type)
			End If

			Dim currentProperties() As PropertyInfo

#If SILVERLIGHT Then
			If Not CompareStaticProperties Then
				currentProperties = type.GetProperties(BindingFlags.Public Or BindingFlags.Instance)
			Else
				currentProperties = type.GetProperties() 'Default is public instance and static
			End If
#Else
			If ComparePrivateProperties AndAlso (Not CompareStaticProperties) Then
				currentProperties = type.GetProperties(BindingFlags.Public Or BindingFlags.NonPublic Or BindingFlags.Instance)
			ElseIf ComparePrivateProperties AndAlso CompareStaticProperties Then
				currentProperties = type.GetProperties(BindingFlags.Public Or BindingFlags.Instance Or BindingFlags.NonPublic Or BindingFlags.Static)
			ElseIf Not CompareStaticProperties Then
				currentProperties = type.GetProperties(BindingFlags.Public Or BindingFlags.Instance)
			Else
				currentProperties = type.GetProperties() 'Default is public instance and static
			End If
#End If

			If Caching Then
				_propertyCache.Add(type, currentProperties)
			End If

			Return currentProperties
		End Function

		''' <summary>
		''' Compare an integer indexer
		''' </summary>
		''' <param name="info"></param>
		''' <param name="object1"></param>
		''' <param name="object2"></param>
		''' <param name="breadCrumb"></param>
		Private Sub CompareIndexer(ByVal info As PropertyInfo, ByVal object1 As Object, ByVal object2 As Object, ByVal breadCrumb As String)
			Dim currentCrumb As String
			Dim indexerCount1 As Integer = CInt(Fix(info.ReflectedType.GetProperty("Count").GetGetMethod().Invoke(object1, New Object() { })))
			Dim indexerCount2 As Integer = CInt(Fix(info.ReflectedType.GetProperty("Count").GetGetMethod().Invoke(object2, New Object() { })))

			'Indexers must be the same length
			If indexerCount1 <> indexerCount2 Then
				currentCrumb = AddBreadCrumb(breadCrumb, info.Name, String.Empty, -1)
				Dim difference As Difference = New Difference With {.ExpectedName = ExpectedName, .ActualName = ActualName, .PropertyName = currentCrumb, .Object1Value = indexerCount1.ToString(CultureInfo.InvariantCulture), .Object2Value = indexerCount2.ToString(CultureInfo.InvariantCulture), .ChildPropertyName = "Count"}
				Differences.Add(difference)

				If Differences.Count >= MaxDifferences Then
					Return
				End If
			End If

			' Run on indexer
			For i As Integer = 0 To indexerCount1 - 1
				currentCrumb = AddBreadCrumb(breadCrumb, info.Name, String.Empty, i)
				Dim objectValue1 As Object = info.GetValue(object1, New Object() { i })
				Dim objectValue2 As Object = info.GetValue(object2, New Object() { i })
				Compare(objectValue1, objectValue2, currentCrumb)

				If Differences.Count >= MaxDifferences Then
					Return
				End If
			Next i
		End Sub

		''' <summary>
		''' Compare a dictionary
		''' </summary>
		''' <param name="object1"></param>
		''' <param name="object2"></param>
		''' <param name="breadCrumb"></param>
		Private Sub CompareIDictionary(ByVal object1 As Object, ByVal object2 As Object, ByVal breadCrumb As String)
			Dim iDict1 As IDictionary = TryCast(object1, IDictionary)
			Dim iDict2 As IDictionary = TryCast(object2, IDictionary)

			'This should never happen, null check happens one level up
			If iDict1 Is Nothing OrElse iDict2 Is Nothing Then
				Return
			End If

			Try
				_parents.Add(object1)
				_parents.Add(object2)

				'Objects must be the same length
				If iDict1.Count <> iDict2.Count Then
					Dim difference As Difference = New Difference With {.ExpectedName = ExpectedName, .ActualName = ActualName, .PropertyName = breadCrumb, .Object1Value = iDict1.Count.ToString(CultureInfo.InvariantCulture), .Object2Value = iDict2.Count.ToString(CultureInfo.InvariantCulture), .ChildPropertyName = "Count"}
					Differences.Add(difference)

					If Differences.Count >= MaxDifferences Then
						Return
					End If
				End If

				Dim enumerator1 As IDictionaryEnumerator = iDict1.GetEnumerator()
				Dim enumerator2 As IDictionaryEnumerator = iDict2.GetEnumerator()

				Do While enumerator1.MoveNext() AndAlso enumerator2.MoveNext()
					Dim currentBreadCrumb As String = AddBreadCrumb(breadCrumb, "Key", String.Empty, -1)

					Compare(enumerator1.Key, enumerator2.Key, currentBreadCrumb)

					If Differences.Count >= MaxDifferences Then
						Return
					End If

					currentBreadCrumb = AddBreadCrumb(breadCrumb, "Value", String.Empty, -1)

					Compare(enumerator1.Value, enumerator2.Value, currentBreadCrumb)

					If Differences.Count >= MaxDifferences Then
						Return
					End If
				Loop
			Finally
				_parents.Remove(object1)
				_parents.Remove(object2)
			End Try
		End Sub

		''' <summary>
		''' Compare an array or something that implements IList
		''' </summary>
		''' <param name="object1"></param>
		''' <param name="object2"></param>
		''' <param name="breadCrumb"></param>
		Private Sub CompareIList(ByVal object1 As Object, ByVal object2 As Object, ByVal breadCrumb As String)
			Dim ilist1 As IList = TryCast(object1, IList)
			Dim ilist2 As IList = TryCast(object2, IList)

			'This should never happen, null check happens one level up
			If ilist1 Is Nothing OrElse ilist2 Is Nothing Then
				Return
			End If

			Try
				_parents.Add(object1)
				_parents.Add(object2)

				'Objects must be the same length
				If ilist1.Count <> ilist2.Count Then
					Dim difference As Difference = New Difference With {.ExpectedName = ExpectedName, .ActualName = ActualName, .PropertyName = breadCrumb, .Object1Value = ilist1.Count.ToString(CultureInfo.InvariantCulture), .Object2Value = ilist2.Count.ToString(CultureInfo.InvariantCulture), .ChildPropertyName = "Count"}
					Differences.Add(difference)

					If Differences.Count >= MaxDifferences Then
						Return
					End If
				End If

				Dim enumerator1 As IEnumerator = ilist1.GetEnumerator()
				Dim enumerator2 As IEnumerator = ilist2.GetEnumerator()
				Dim count As Integer = 0

				Do While enumerator1.MoveNext() AndAlso enumerator2.MoveNext()
					Dim currentBreadCrumb As String = AddBreadCrumb(breadCrumb, String.Empty, String.Empty, count)

					Compare(enumerator1.Current, enumerator2.Current, currentBreadCrumb)

					If Differences.Count >= MaxDifferences Then
						Return
					End If

					count += 1
				Loop
			Finally
				_parents.Remove(object1)
				_parents.Remove(object2)
			End Try
		End Sub

		''' <summary>
		''' Compare a HashSet
		''' </summary>
		''' <param name="object1"></param>
		''' <param name="object2"></param>
		''' <param name="breadCrumb"></param>
		Private Sub CompareHashSet(ByVal object1 As Object, ByVal object2 As Object, ByVal breadCrumb As String)
			Try
				_parents.Add(object1)
				_parents.Add(object2)

				Dim t1 As Type = object1.GetType()

				'Get count by reflection since we can't cast it to HashSet<>
				Dim hashSet1Count As Integer = CInt(Fix(GetPropertyValue(t1, object1, "Count")))
				Dim hashSet2Count As Integer = CInt(Fix(GetPropertyValue(t1, object2, "Count")))

				'Objects must be the same length
				If hashSet1Count <> hashSet2Count Then
					Dim difference As Difference = New Difference With {.ExpectedName = ExpectedName, .ActualName = ActualName, .PropertyName = breadCrumb, .Object1Value = hashSet1Count.ToString(CultureInfo.InvariantCulture), .Object2Value = hashSet2Count.ToString(CultureInfo.InvariantCulture), .ChildPropertyName = "Count"}
					Differences.Add(difference)

					If Differences.Count >= MaxDifferences Then
						Return
					End If
				End If

				'Get enumerators by reflection
				Dim methodInfo As MethodInfo = GetMethod(t1, "GetEnumerator")
				Dim enumerator1 As IEnumerator = CType(methodInfo.Invoke(object1, Nothing), IEnumerator)
				Dim enumerator2 As IEnumerator = CType(methodInfo.Invoke(object2, Nothing), IEnumerator)

				Dim count As Integer = 0

				Do While enumerator1.MoveNext() AndAlso enumerator2.MoveNext()
					Dim currentBreadCrumb As String = AddBreadCrumb(breadCrumb, String.Empty, String.Empty, count)

					Compare(enumerator1.Current, enumerator2.Current, currentBreadCrumb)

					If Differences.Count >= MaxDifferences Then
						Return
					End If

					count += 1
				Loop
			Finally
				_parents.Remove(object1)
				_parents.Remove(object2)
			End Try
		End Sub
		#End Region

		#Region "IsType methods"

		''' <summary>
		''' Returns true if the Type is a Runtime type
		''' </summary>
		''' <param name="type"></param>
		''' <returns></returns>
		Private Function IsTypeOfType(ByVal type As Type) As Boolean
			Return (GetType(Type).IsAssignableFrom(type))
		End Function

		''' <summary>
		''' Check if any type has attributes that should be bypassed
		''' </summary>
		''' <returns></returns>
		Private Function IgnoredByAttribute(ByVal type As Type) As Boolean
			Return AttributesToIgnore.Any(Function(attributeType) type.GetCustomAttributes(True).Length > 0)
		End Function

		'/// <summary>
		'/// Ignore individual property or field
		'/// </summary>
		'/// <param name="info"></param>
		'/// <returns></returns>
		'private bool IgnoredByAttribute(MemberInfo info)
		'{
		'    return AttributesToIgnore.Any(ignoredType => info.GetCustomAttributes(ignoredType, false).Length > 0);
		'}

		Private Function IsTimespan(ByVal type As Type) As Boolean
			Return type Is GetType(TimeSpan)
		End Function

		Private Function IsPointer(ByVal type As Type) As Boolean
			Return type Is GetType(IntPtr) OrElse type Is GetType(UIntPtr)
		End Function

		Private Function IsEnum(ByVal type As Type) As Boolean
			Return type.IsEnum
		End Function

		Private Function IsStruct(ByVal type As Type) As Boolean
			Return type.IsValueType AndAlso Not IsSimpleType(type)
		End Function

		Private Function IsSimpleType(ByVal type As Type) As Boolean
			If type.IsGenericType AndAlso type.GetGenericTypeDefinition().Equals(GetType(Nullable(Of ))) Then
				type = Nullable.GetUnderlyingType(type)
			End If

			Return type.IsPrimitive OrElse type Is GetType(Date) OrElse type Is GetType(Decimal) OrElse type Is GetType(String) OrElse type Is GetType(Guid)

		End Function

		Private Function ValidStructSubType(ByVal type As Type) As Boolean
			Return IsSimpleType(type) OrElse IsEnum(type) OrElse IsArray(type) OrElse IsClass(type) OrElse IsIDictionary(type) OrElse IsTimespan(type) OrElse IsIList(type)
		End Function

		Private Function IsArray(ByVal type As Type) As Boolean
			Return type.IsArray
		End Function

		Private Function IsClass(ByVal type As Type) As Boolean
			Return type.IsClass
		End Function

		Private Function IsIDictionary(ByVal type As Type) As Boolean
			Return (GetType(IDictionary).IsAssignableFrom(type))
		End Function

#If Not SILVERLIGHT Then
		Private Function IsDataset(ByVal type As Type) As Boolean
			Return type Is GetType(DataSet)
		End Function

		Private Function IsDataRow(ByVal type As Type) As Boolean
			Return type Is GetType(DataRow)
		End Function

		Private Function IsDataTable(ByVal type As Type) As Boolean
			Return type Is GetType(DataTable)
		End Function
#End If

		Private Function IsIPEndPoint(ByVal type As Type) As Boolean
			Return type Is GetType(IPEndPoint)
		End Function

		Private Function IsIList(ByVal type As Type) As Boolean
			Return (GetType(IList).IsAssignableFrom(type))
		End Function

		Private Function IsChildType(ByVal type As Type) As Boolean
			Return (Not IsSimpleType(type)) AndAlso (IsClass(type) OrElse IsArray(type) OrElse IsIDictionary(type) OrElse IsIList(type) OrElse IsStruct(type) OrElse IsHashSet(type))
		End Function

		Private Function IsUri(ByVal type As Type) As Boolean
			Return (GetType(Uri).IsAssignableFrom(type))
		End Function

		Private Function IsHashSet(ByVal type As Type) As Boolean
			Return type.IsGenericType AndAlso type.GetGenericTypeDefinition().Equals(GetType(HashSet(Of )))
		End Function

		#End Region

		#Region "Validity Checking"
		Private Function IsValidIndexer(ByVal info As PropertyInfo, ByVal breadCrumb As String) As Boolean
			Dim indexers() As ParameterInfo = info.GetIndexParameters()

			If indexers.Length = 0 Then
				Return False
			End If

			If indexers.Length > 1 Then
				Throw New Exception("Cannot compare objects with more than one indexer for object " & breadCrumb)
			End If

			If indexers(0).ParameterType IsNot GetType(Int32) Then
				Throw New Exception("Cannot compare objects with a non integer indexer for object " & breadCrumb)
			End If

			If info.ReflectedType.GetProperty("Count") Is Nothing Then
				Throw New Exception("Indexer must have a corresponding Count property for object " & breadCrumb)
			End If

			If info.ReflectedType.GetProperty("Count").PropertyType IsNot GetType(Int32) Then
				Throw New Exception("Indexer must have a corresponding Count property that is an integer for object " & breadCrumb)
			End If

			Return True
		End Function
		#End Region

		#Region "Supporting Methods"

		''' <summary>
		''' Get the value of a property
		''' </summary>
		''' <param name="type"></param>
		''' <param name="objectValue"></param>
		''' <param name="propertyName"></param>
		''' <returns></returns>
		Private Function GetPropertyValue(ByVal type As Type, ByVal objectValue As Object, ByVal propertyName As String) As Object
			Return GetPropertyInfo(type).First(Function(o) o.Name = propertyName).GetValue(objectValue, Nothing)
		End Function

		''' <summary>
		''' Get a method by name
		''' </summary>
		''' <param name="type"></param>
		''' <param name="methodName"></param>
		''' <returns></returns>
		Private Function GetMethod(ByVal type As Type, ByVal methodName As String) As MethodInfo
			Return GetMethods(type).FirstOrDefault(Function(m) m.Name = methodName)
		End Function

		''' <summary>
		''' Get the cached methods for a type
		''' </summary>
		''' <param name="type"></param>
		''' <returns></returns>
		Private Function GetMethods(ByVal type As Type) As IEnumerable(Of MethodInfo)
			If _methodList.ContainsKey(type) Then
				Return _methodList(type)
			End If

			Dim myMethodInfo() As MethodInfo = type.GetMethods()
			_methodList.Add(type, myMethodInfo)
			Return myMethodInfo
		End Function

		''' <summary>
		''' Convert an object to a nicely formatted string
		''' </summary>
		''' <param name="obj"></param>
		''' <returns></returns>
		Private Function NiceString(ByVal obj As Object) As String
			Try
				If obj Is Nothing Then
					Return "(null)"
				End If

				If obj Is DBNull.Value Then
					Return "System.DBNull.Value"
				End If

				Return obj.ToString()
			Catch
				Return String.Empty
			End Try
		End Function

		''' <summary>
		''' Add a breadcrumb to an existing breadcrumb
		''' </summary>
		''' <param name="existing"></param>
		''' <param name="name"></param>
		''' <param name="extra"></param>
		''' <param name="index"></param>
		''' <returns></returns>
		Private Function AddBreadCrumb(ByVal existing As String, ByVal name As String, ByVal extra As String, ByVal index As Integer) As String
			Return AddBreadCrumb(existing, name, extra,If(index >= 0, index.ToString(CultureInfo.InvariantCulture), Nothing))
		End Function

		''' <summary>
		''' Add a breadcrumb to an existing breadcrumb
		''' </summary>
		''' <param name="existing"></param>
		''' <param name="name"></param>
		''' <param name="extra"></param>
		''' <param name="index"></param>
		''' <returns></returns>
		Private Function AddBreadCrumb(ByVal existing As String, ByVal name As String, ByVal extra As String, ByVal index As String) As String
			Dim useIndex As Boolean = Not String.IsNullOrEmpty(index)
			Dim useName As Boolean = name.Length > 0
			Dim sb As New StringBuilder()

			sb.Append(existing)

			If useName Then
				sb.AppendFormat(".")
				sb.Append(name)
			End If

			sb.Append(extra)

			If useIndex Then
' ReSharper disable RedundantAssignment
				Dim result As Integer = -1
' ReSharper restore RedundantAssignment
				sb.AppendFormat(If(Int32.TryParse(index, result), "[{0}]", "[""{0}""]"), index)
			End If

#If BREADCRUMB Then
			Console.WriteLine(sb.ToString())
#End If

			Return sb.ToString()
		End Function
		#End Region
	End Class

	''' <summary>
	''' Detailed information about the difference
	''' </summary>
	Public Class Difference
		''' <summary>
		''' Name of Expected Object
		''' </summary>
		Public Property ExpectedName() As String

		''' <summary>
		''' Name of Actual Object
		''' </summary>
		Public Property ActualName() As String

		''' <summary>
		''' The breadcrumb of the property leading up to the value
		''' </summary>
		Public Property PropertyName() As String

		''' <summary>
		''' The child property name
		''' </summary>
		Public Property ChildPropertyName() As String

		''' <summary>
		''' Object1 Value
		''' </summary>
		Public Property Object1Value() As String

		''' <summary>
		''' Object2 Value
		''' </summary>
		Public Property Object2Value() As String

		''' <summary>
		''' Prefix to put on the beginning of the message
		''' </summary>
		Public Property MessagePrefix() As String

		Public Overrides Function ToString() As String
			Dim message As String

			If Not String.IsNullOrEmpty(PropertyName) Then
				If String.IsNullOrEmpty(ChildPropertyName) Then
					message = String.Format("{0}.{2} != {1}.{2} ({3},{4})", ExpectedName, ActualName,PropertyName,Object1Value, Object2Value)
				Else
					message = String.Format("{0}.{2}.{5} != {1}.{2}.{5} ({3},{4})", ExpectedName, ActualName, PropertyName, Object1Value, Object2Value, ChildPropertyName)
				End If
			Else
				message = String.Format("{0} != {1} ({2},{3})", ExpectedName, ActualName, Object1Value, Object2Value)
			End If

			If Not String.IsNullOrEmpty(MessagePrefix) Then
				message = String.Format("{0}: {1}", MessagePrefix, message)
			End If

			Return message
		End Function
	End Class
End Namespace