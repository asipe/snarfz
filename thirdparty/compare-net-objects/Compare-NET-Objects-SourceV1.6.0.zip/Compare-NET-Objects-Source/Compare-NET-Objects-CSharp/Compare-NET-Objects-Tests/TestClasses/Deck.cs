﻿
namespace KellermanSoftware.CompareNETObjectsTests.TestClasses
{
    public enum Deck 
    {
        Engineering,
        SickBay,
        AstroPhysics
    }
}
