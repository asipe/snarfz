﻿using System;

namespace KellermanSoftware.CompareNETObjectsTests.TestClasses
{
    public class Table
    {
        public string TableName { get; set; }
        public Type ClassType { get; set; }
    }
}
