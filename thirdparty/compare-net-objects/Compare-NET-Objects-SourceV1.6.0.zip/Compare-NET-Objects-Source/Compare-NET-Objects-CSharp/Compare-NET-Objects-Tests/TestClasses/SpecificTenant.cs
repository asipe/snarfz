﻿namespace KellermanSoftware.CompareNETObjectsTests.TestClasses
{
    public class SpecificTenant
    {
        public string Name { get; set; }

        public int Amount { get; set; }
    }
}
