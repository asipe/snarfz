﻿namespace KellermanSoftware.CompareNETObjectsTests.TestClasses
{
    public class HashSetClass
    {
        public int Id { get; set; }
    }
}
