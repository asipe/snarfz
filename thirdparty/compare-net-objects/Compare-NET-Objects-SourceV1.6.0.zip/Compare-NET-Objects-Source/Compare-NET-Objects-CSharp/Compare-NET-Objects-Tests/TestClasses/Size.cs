﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KellermanSoftware.CompareNETObjectsTests.TestClasses
{
    public struct Size
    {
        public int Width;
        public int Height;
    }
}
